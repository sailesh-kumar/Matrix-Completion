#include <stdio.h>
#include <stdint.h>
#include <inttypes.h>
typedef union{
	long long i;
	long double f;
}U;
int main(void){
	U u;
	U v;
	U w;
	U y;
	U z;
	FILE *in_file, *out_file,*out_file_y, *in_file_y, *in_file_ProjM, *out_file_ProjM, *p_file, *p_file_out,*in_file_m_in,*out_file_m_in;
	char buf[100], buf1[100];
	long double fl,fl1;
	int x;
	int m = 15;
	int n = 10;
	int r = 5;
	in_file = fopen("HDLfileXo.txt","r");
	in_file_y = fopen("HDLfileYo.txt","r");
	in_file_ProjM = fopen("HDLfileProjM.txt","r");
	in_file_m_in = fopen("HDLfileM_in.txt","r");
	out_file_m_in = fopen("out_m_in.txt","w");
	out_file = fopen("out_x0.txt","w");
	out_file_y = fopen("out_y0.txt","w");
	out_file_ProjM = fopen("out_ProjM.txt","w");
	
	p_file = fopen("HDLCfileConstantp_beta1_betaT.txt","r");
	p_file_out = fopen("out_p.txt","w");
	for(x=1;x<=m*r;x++){
		if(x%r==0){
			fscanf(in_file,"%s\n",&buf);
			sscanf(buf,"%lg\n",&fl);
			u.f = fl;
			fprintf(out_file,"%llx\n",(u.i));
		}
		else {
			fscanf(in_file,"%s\t",&buf);
			sscanf(buf,"%lg\t",&fl);
			u.f = fl;
			fprintf(out_file,"%llx\t",(u.i));
		}
	}
	for(x=1;x<=n*r;x++){
		if(x%r==0){
			fscanf(in_file_y,"%s\n",&buf);
			
			
			sscanf(buf,"%lg\n",&fl);
			y.f = fl;
			//printf("%#x\n",&fl);
			fprintf(out_file_y,"%llx\n",y.i);
		}
		else {
			fscanf(in_file_y,"%s\t",&buf);
			sscanf(buf,"%lg\t",&fl);
			y.f = fl;
			//printf("%#x\t",&fl);
			fprintf(out_file_y,"%llx\t",y.i);
		}
	}
	for(x=1;x<=m*n;x++){
		if(x%n==0){
			fscanf(in_file_ProjM,"%s\n",&buf);			
			sscanf(buf,"%g\n",&fl);
			v.f = fl;
			fprintf(out_file_ProjM,"%x\n",v.i);
			
			fscanf(in_file_m_in,"%s\n",&buf1);			
			sscanf(buf1,"%g\n",&fl1);
			z.f = fl1;
			fprintf(out_file_m_in,"%x\n",z.i);
		}
		else {
			fscanf(in_file_ProjM,"%s\t",&buf1);			
			sscanf(buf1,"%lg\t",&fl1);
			v.f = fl1;
			fprintf(out_file_ProjM,"%llx\t",v.i);
			
			fscanf(in_file_m_in,"%s\t",&buf);
			sscanf(buf,"%lg\t",&fl);
			z.f = fl;
			fprintf(out_file_m_in,"%llx\t",z.i);
		}
	}
	for(x=1;x<=6;x++){
	 fscanf(p_file,"%s\n",&buf);
	 sscanf(buf,"%lg\n",&fl);
	 w.f = fl;
	 fprintf(p_file_out,"%llx\n",w.i);
	}
	
}
