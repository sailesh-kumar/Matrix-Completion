 format long; 
 clc;
 clear all;

 r=5;
 m=15;
 n=10;
 Co=10^-18;
 Cd=54;
 Ct=20;
 M=rand(m,r)*rand(r,n);
 
 [U, S, V]=svds(M,r);
 Smax=max(S(:,1));
 Smin=min(S(S>min(S(:,r))));
 k=Smax/Smin;
 alpha=m/n;
 ma=floor((max(m,n)/r));
 mu=randi([1 ma],1);
 la=floor(Co*alpha*n*r*k*max((mu*log(n)),(sqrt(alpha)*(mu^2)*(r^6)*(k^4))));
 sigmaNo=((m*n)-la).*rand(1,1) + la;
 po=floor(sigmaNo)/(m*n);
 lamda=Smin/(Cd*(r^1.5)*k);
 lamdaNo=lamda/6;
 p=8*po*(lamdaNo^2);

M_text=cell(m,n);
for i=1:m
    for j=1:n
         M_text{i,j}=M(i,j);
    end
end

fid61 = fopen('HDLfileM_in.txt', 'wt'); % Open for writing
for i=1:m
    for j=1:n
       fprintf(fid61, '%.20f ',M_text{i,j} );
    end
    fprintf(fid61, '\n');
end

betaT=sqrt(Ct*r*Smax);
beta1=betaT*sqrt((3*mu*r)/m);

beta2=betaT*sqrt((3*mu*r)/n);

msize=numel(M);
Omega =randperm(msize,floor(sigmaNo)+1)';
randsample(m*n,floor(sigmaNo)+1);
mO=length(Omega);
data = M(Omega);
[i,j]=ind2sub([m,n], Omega);
ProjM = sparse(i,j,data,m,n,mO);
ProjM =full(ProjM);


ProjM_text=cell(m,n);
for i=1:m
    for j=1:n
         ProjM_text{i,j}=ProjM(i,j);
    end
end

fid62 = fopen('HDLfileProjM.txt', 'wt'); % Open for writing
for i=1:m
    for j=1:n
       fprintf(fid62, '%.20f ',ProjM(i,j) );
    end
    fprintf(fid62, '\n');
end

[Xs, D, Ys]=svds((1/po).*ProjM,r);
Xo=Xs*(D.^(1/2));
Yo=Ys*(D.^(1/2));

msize=numel(M);
Omega =randperm(msize,floor(sigmaNo)+1)';
G=(Xo*transpose(Yo))-ProjM;

GDxF= G*Yo;
GDyF= transpose(G)*Xo;

Gox=zeros(m,1);
Goy=zeros(n,1);
GY1=zeros(n,r);
G1=zeros(m,r);
Gxx2=zeros(m,r);
Xn=zeros(m,1);
Yn=zeros(n,1);
z=zeros(m,1);
zy=zeros(m,1);


for i=1:m
    Xi=zeros(m,r);
    Xn(i,1)=norm(Xo(i,:));
    
    z(i)=(3*(Xn(i,1))^2)/(2*beta1^2);
    if z(i)>=0 && z(i)<inf
    GD1=2*(z(i)-1);
    else
    GD1=0;
    end
    Xi(i,:)=Xo(i,:);
    Gox=Xi.*((GD1*3)/(beta1^2));
    G1=G1+Gox;
     
end

Xf=norm(Xo,'fro');
zz=(3*(Xf)^2)/(2*betaT^2);
    if zz>=0 && zz<inf
    GD2=2*(zz-1);
    else
    GD2=0;
    end
    G2=Xo.*((GD2*3)/(betaT^2));
    
    Gxx2=G1+G2;
    
for i=1:n
    Yi=zeros(n,r);
    Yn(i,1)=norm(Yo(i,:));
    
    zy(i)=(3*(Yn(i,1))^2)/(2*beta2^2);
    if zy(i)>=0 && zy(i)<inf
    GDy1=2*(zy(i)-1);
    else
    GDy1=0;
    end
    Yi(i,:)=Yo(i,:);
    Goy=Yi.*((GDy1*3)/(beta2^2));
    GY1=GY1+Goy;
     
end

Yf=norm(Yo,'fro');
zz=(3*(Yf)^2)/(2*betaT^2);
    if zz>=0 && zz<inf
    GDy2=2*(zz-1);
    else
    GDy2=0;
    end
    GY2=Yo.*((GDy2*3)/(betaT^2));
    Gyy2=GY1+GY2;

    
gradFGx=p*(Gxx2+GDxF);
gradFGy=p*(Gyy2+GDyF);
YY=Yo;
XX=Xo;

Pyo=cell(n,r);
for i=1:n
    for j=1:r
         Pyo{i,j}=(YY(i,j));
     end
end

fid4 = fopen('HDLfileYo.txt', 'wt'); % Open for writing
for i=1:n
    for j=1:r
       fprintf(fid4, '%.20f ',Pyo{i,j} );
    end
    fprintf(fid4, '\n');
end

Pxo=cell(m,r);
for i=1:m
    for j=1:r
         Pxo{i,j}=XX(i,j);
    end
end

fid3 = fopen('HDLfileXo.txt', 'wt'); % Open for writing
for i=1:m
    for j=1:r
       fprintf(fid3, '%.20f ',Pxo{i,j} );
    end
    fprintf(fid3, '\n');
end

nd=1/(2*betaT);
nk(1,1)=(nd)*rand(1,1);

maxiter=1;
Xk1=Xo;
Yk1=Yo;
Xk=zeros(m,r);
Xt=zeros(m,r);
Yk=zeros(n,r);
ll=zeros(floor(n*r*log(n)),1);
Xo1=cell(floor(n*r*log10(n)),1);
Yo1=cell(floor(n*r*log10(n)),1);
flag=true;
 while (maxiter<=n*r*log10(n) && flag)

Xo1{maxiter}=Xk1- (nk.*gradFGx);
Yo1{maxiter}=Yk1- (nk.*gradFGy);
 
msize=numel(M);
Omega =randperm(msize,floor(sigmaNo)+1)';
G=(Xo1{maxiter}*transpose(Yo1{maxiter}))-ProjM;

GDxF= G*Yo1{maxiter};
GDyF= transpose(G)*Xo1{maxiter};

Gox=zeros(m,1);
Goy=zeros(n,1);
GY1=zeros(n,r);
G1=zeros(m,r);
Gxx2=zeros(m,r);
Xn=zeros(m,1);
Yn=zeros(n,1);
z=zeros(m,1);
zy=zeros(m,1);


for i=1:m
    Xi=zeros(m,r);
    Xn(i,1)=norm(Xo1{maxiter}(i,:));
    
    z(i)=(3*(Xn(i,1))^2)/(2*beta1^2);
    if z(i)>=0 && z(i)<inf
    GD1=2*(z(i)-1);
    else
    GD1=0;
    end
    Xi(i,:)=Xo1{maxiter}(i,:);
    Gox=Xi.*((GD1*3)/(beta1^2));
    G1=G1+Gox;
     
end

Xf=norm(Xo1{maxiter},'fro');
zz=(3*(Xf)^2)/(2*betaT^2);
    if zz>=0 && zz<inf
    GD2=2*(zz-1);
    else
    GD2=0;
    end
    G2=Xo1{maxiter}.*((GD2*3)/(betaT^2));
    
    Gxx2=G1+G2;
    
for i=1:n
    Yi=zeros(n,r);
    Yn(i,1)=norm(Yo1{maxiter}(i,:));
    
    zy(i)=(3*(Yn(i,1))^2)/(2*beta2^2);
    if zy(i)>=0 && zy(i)<inf
    GDy1=2*(zy(i)-1);
    else
    GDy1=0;
    end
    Yi(i,:)=Yo1{maxiter}(i,:);
    Goy=Yi.*((GDy1*3)/(beta2^2));
    GY1=GY1+Goy;
     
end

Yf=norm(Yo1{maxiter},'fro');
zz=(3*(Yf)^2)/(2*betaT^2);
    if zz>=0 && zz<inf
    GDy2=2*(zz-1);
    else
    GDy2=0;
    end
    GY2=Yo1{maxiter}.*((GDy2*3)/(betaT^2));
    Gyy2=GY1+GY2;

    
gradFGx=p*(Gxx2+GDxF);
gradFGy=p*(Gyy2+GDyF);

   normXk1=sum(Xo1{maxiter}.^2,2).^(1/2); 
   normYk1=sum(Yo1{maxiter}.^2,2).^(1/2);
   
   ii=0;
   for i=1:m
       if(normXk1(i)<=beta1)
           ii=ii+1;
       end
   end
   
      jj=0;
   for j=1:n
       if(normYk1(j)<=beta2)
           jj=jj+1;
       end
   end
   
 if  ((ii==m) && (jj==n) &&(norm(Xo1{maxiter},'fro')<=betaT) && (norm(Yo1{maxiter},'fro')<=betaT) && (norm(M-Xo1{maxiter}*transpose(Yo1{maxiter}),'fro')<=lamda))
  flag =false;
 end
 
  Xk1=Xo1{maxiter};
  Yk1=Yo1{maxiter};    
 maxiter=maxiter+1;  
 end




fid1 = fopen('HDLCfileConstantp_beta1_betaT.txt', 'wt'); % Open for writing

   fprintf(fid1, '%.30f', p);
   fprintf(fid1, '\n');

  
   fprintf(fid1, '%.20f ', beta1);
   fprintf(fid1, '\n');
    

   fprintf(fid1, '%.20f ', beta2);
   fprintf(fid1, '\n');
   
   fprintf(fid1, '%.20f ', betaT);
   fprintf(fid1, '\n');
   
      fprintf(fid1, '%.20f', nk);
   fprintf(fid1, '\n');
   
   fprintf(fid1, '%.20f', lamdaNo);
   fprintf(fid1, '\n');
   


fclose(fid1);
